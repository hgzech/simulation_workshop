function [a, r, CKt, p] = simulate_M4ChoiceKernel_v2(T, mu, alpha_c, beta_c)

%% v2: THM- Updated outputs to the function and saving CK and p values across trials

% Simulate Model 4: Choice Kernel
        % two free parameters, ck learning rate and ck inverse temperature
        % model assumes participants compute a ck for each action, which
        % keeps track of how frequently they have chosen that option in the
        % recent past

    % Inputs:
        % <T> total number of trials
        % <mu> mean reward probabilities of bandits (options)
        % <alpha> ck learning rate - between 0 and 1
        % <beta> ck inverse temperature - level of stochasticity in choice
              % ranges from 0 = completely random to infinity = deterministically choosing highest opt
    % Outputs:
        % a = choices (1's and 2's for length of trials)
        % r = rewards (logical array of 0's and 1's)
    %% Added to the original from Collins & Wilson
        % CKt = the CK values for A and B
        % p = the choice probabilities for A and B

CK = [0 0]; % initial values

% initialize these variables (store values across trials)
 CKt  = nan(T, 2);
 p  = nan(T, 2);


for t = 1:T
    
    % added trial indexing to track these values across trials
    CKt(t,:) = CK;

    % compute choice probabilities
    p(t,:) = exp(beta_c*CK) / sum(exp(beta_c*CK));
    
    % make choice according to choice probababilities
    a(t) = choose(p(t,:)); % separate function
    
    % generate reward based on choice
    r(t) = rand < mu(a(t));
    
    % update choice kernel
    CK = (1-alpha_c) * CK;
    CK(a(t)) = CK(a(t)) + alpha_c * 1;
            
    
end
