function a = choose(p)

% Input:
        % <p> choice probabilities for opts, e.g. p = [b 1-b]
% Output:
        % <a> option chosen, 1 or 2


a = max(find([-eps cumsum(p)] < rand));
