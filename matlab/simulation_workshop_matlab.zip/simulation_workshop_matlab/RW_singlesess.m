% --------------------------------------------------- %
%        Simulation of Rescorla Wagner Model          % 
% --------------------------------------------------- %

% THM adapted code from paper:
% Wilson RC, Collins AG.
% Ten simple rules for the computational modeling of behavioral data. 
% Elife. 2019 Nov 26;8:e49547. doi: 10.7554/eLife.49547. 
% Download from git: https://github.com/AnneCollins/TenSimpleRulesModeling.git

% Original script name: Figure2_simulations


%% Single Subject/Session

clear

addpath('./SimulationFunctions') % kept filepath structure
% path needed for: simulate_M3RescorlaWagner_v2.m and choose.m

% experiment parameters
T   = 100;         % number of trials
mu  = [0.2 0.8];    % mean reward of bandits

% Model 3: Rescorla Wagner
    alpha = 0.1; % learning rate 
    beta = 5; % inverse temperature 

    %% updates to this function to save Q values, probabilities, and deltas(PE) for plotting
    [a, r, delta, Qt, p] = simulate_M3RescorlaWagner_v2(T, mu, alpha, beta); 

    simRW.a = a;
    simRW.r = r;
    % Added these values to the sim struct to use for plotting below
    simRW.PE = delta;
    simRW.QA = Qt(:,1); 
    simRW.QB = Qt(:,2); 
    simRW.PA = p(:,1);
    simRW.PB = p(:,2);


%% Plot Q values, probabilities, and choices over trials

%% Single Session
figure


% display the simulation results for predicted value
% evolution of the Q values for the two options
% blue - option A and the value decreases over time
% red - option B and the value increases over time
subplot(2, 1, 1)
hold on
plot(simRW.QA, '-b'); % bad option in blue- plot col 1
plot(simRW.QB, '-r'); % good option in red- plot col 2
plot(simRW.a - 1, 'o'); % convert to 0's and 1's: dots (1 = B and 0 = A)
plot(simRW.PE, '-k');
xlim([0, T]);
ylim([-1.1, 1.1]);
xlabel('trials');
ylabel('Q-values');
legend('A','B','Choice');


% display the simulation results for choice probabilities
% colored lines- probabilities of choice
% dots- are choices (1 = B and 0 = A)
subplot(2, 1, 2);
hold on
plot(simRW.PA, '-b'); % bad option in blue- plot col 1
plot(simRW.PB, '-r'); % good option in red- plot col 2
plot(simRW.a- 1, 'o'); 
xlim([0, T]);
ylim([-0.1, 1.1]);
xlabel('trials');
ylabel('Probability');
legend('ProbA','ProbB','Choice');



% Save the simulation 
filename = 'simRW_data_singlesess';
save(filename, 'simRW','alpha', 'beta', 'T')
path = pwd;
fprintf('saved simulationd data: %s/%s.mat \n', path, filename)



