% --------------------------------------------------- %
%        Simulation of Choice Kernel Model          % 
% --------------------------------------------------- %

% THM adapted code from paper:
% Wilson RC, Collins AG.
% Ten simple rules for the computational modeling of behavioral data. 
% Elife. 2019 Nov 26;8:e49547. doi: 10.7554/eLife.49547. 
% Download from git: https://github.com/AnneCollins/TenSimpleRulesModeling.git

% Original script name: Figure2_simulations

clear

%% Multiple Subject/Session

clear

addpath('./SimulationFunctions') % kept filepath structure
% path needed for: simulate_M4ChoiceKernel_v2.m and choose.m

% experiment parameters
T   = 100;         % number of trials
mu  = [0.2 0.8];    % mean reward of bandits

%% Add Nrep variable
% number of repetitions for simulations
Nrep = 110;

% Model 4: Choice kernel (ck)
for n = 1:Nrep
    alpha_c = 0.1; %ck learning rate
    beta_c = 3; %ck inverse temperature

     %% updates to this function to save CK values and probabilities for plotting
    [a, r, CKt, p] = simulate_M4ChoiceKernel_v2(T, mu, alpha_c, beta_c);

    simCK.a(:,n) = a;
    simCK.r(:,n) = r;
    % Added these values to the sim struct to use for plotting below
    simCK.CKA(:,n) = CKt(:,1); 
    simCK.CKB(:,n) = CKt(:,2); 
    simCK.PA(:,n) = p(:,1);
    simCK.PB(:,n) = p(:,2);
end


%% Plot Q values, probabilities, and choices over trials


%% Choice Kernel
%% Single Session
figure

% choose a session at random for single plot
sessn = randi(Nrep);

% display the simulation results for predicted value
% evolution of the Q values for the two options
% blue - option A and the value decreases over time
% red - option B and the value increases over time
subplot(2, 1, 1)
hold on
plot(simCK.CKA(:,sessn), '-b'); % bad option in blue- plot col 1
plot(simCK.CKB(:,sessn), '-r'); % good option in red- plot col 2
plot(simCK.a(:,sessn)- 1, 'o'); % convert to 0's and 1's: dots (1 = B and 0 = A)
xlim([0, T]);
ylim([-0.1, 1.1]);
xlabel('trials');
ylabel('CK-values');
legend('A','B','Choice');


% display the simulation results for choice probabilities
% colored lines- probabilities of choice
% dots- are choices (1 = B and 0 = A)
subplot(2, 1, 2);
hold on
plot(simCK.PA(:,sessn), '-b'); % bad option in blue- plot col 1
plot(simCK.PB(:,sessn), '-r'); % good option in red- plot col 2
plot(simCK.a(:,sessn)- 1, 'o'); 
xlim([0, T]);
ylim([-0.1, 1.1]);
xlabel('trials');
ylabel('Probability');
legend('ProbA','ProbB','Choice');

%% New figure across all sessions
figure;
% Across all sessions
subplot(2, 1, 1)
hold on
plot(mean(simCK.CKA,2), '-b');
plot(mean(simCK.CKB,2), '-r');
xlim([0, T]);
ylim([-0.1, 1.1]);
xlabel('trials');
ylabel('Q-values');
legend('A','B');

subplot(2, 1, 2);
hold on
plot(mean(simCK.PB,2), '-r'); % good option in red- plot col 2
plot(mean(simCK.a - 1,2), 'o');
xlim([0, T]);
ylim([-0.1, 1.1]);
xlabel('trials');
ylabel('Probability');
legend('ProbB','Choice');




% Save the simulation 
filename = 'simCK_data_multsess';
save(filename, 'simCK', 'alpha_c','beta_c', 'Nrep', 'T', 'sessn')
path = pwd;
fprintf('saved simulationd data: %s/%s.mat \n', path, filename)


